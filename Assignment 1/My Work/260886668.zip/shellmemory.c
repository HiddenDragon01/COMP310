#include<stdio.h>
#include<string.h>
#include<stdlib.h>

struct mem {
	char *var;
	char *value;

};

struct mem *memory;

int memindex;

void allocateMemory() {
	memory = malloc (1000 * sizeof(struct mem));
	memindex = 0;
}

void StoreMemory(char *a, char *b) {

	for (int i = 0; i < memindex; i++) {
                if (strcmp(memory[i].var, a) == 0) {
			memory[i].value = b;
                        return;
                }
        }
	memory[memindex].var = a;
	memory[memindex++].value = b;
}

void printVariable(char *a) {
	
	for (int i = 0; i < memindex; i++) {
		if (strcmp(memory[i].var, a) == 0) {
			printf("%s\n", memory[i].value);
			return;
		}
	}
	printf("Variable does not exist\n");
}

