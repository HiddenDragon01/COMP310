void parse(char *string, char *tokens[]);
int quit;
