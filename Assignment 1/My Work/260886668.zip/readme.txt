Name: Ryan Sowa
ID#: 260886668

To obtain the executable, mysh, type "make"
To remove all the .o files and the executable, type "make clean"
