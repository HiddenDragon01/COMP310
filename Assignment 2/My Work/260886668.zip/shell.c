// Name: Ryan Sowa
// ID#: 260886668
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "interpreter.h"
#include "shellmemory.h"

void parse(char *st, char *to[]) {
        char bu[1000];
        int s=0, b=0, t=0; // counters for string, buffer and tokens
	

	while(*(st+s) != '\0' && *(st+s) != '\n' && *(st+s) != '\t' && *(st+s) != '\r') {
                // skip leading spaces
                for(;*(st+s)==' ';s++);  // super cool no?!

                // exit if end of string
                if (*(st+s) == '\0' || *(st+s) == '\n' || *(st+s) == '\t' || *(st+s) == '\r') break;

                // otherwise, add word to buffer
                b=0;
                while(*(st+s)!=' ' && *(st+s)!='\0' && *(st+s) != '\n' && *(st+s) != '\t' && *(st+s) != '\r') {
                        bu[b] = *(st+s);
                        s++;
                        b++;
                }
                bu[b]='\0'; // make it a string

                // create a token
                to[t] = strdup(bu);
                t++;
        }
        to[t] = NULL;
}

int quit;


int shellUI() {
	
	char buffer[1000];
	allocateMemory();
	printf("Kernel 1.0 loaded!\nWelcome to the Ryan shell!\nShell version 2.0 Updated February 2021\n");

	while (1) {
		char *tokens[1000], *string;
		string = malloc(256);
		memset(string, 0x00, 256);
		printf("$ ");
		fgets(buffer, 1000, stdin);
		int index = 0;
		for (int i = 0; buffer[i] != '\0' && buffer[i] != '\n'; i++) {
			*(string + (index++)) = buffer[i];
		}
		parse(string, tokens);

		if (tokens[0] == NULL) {
			printf("Unknown command\n");
			continue;
		}

		interpreter(tokens);
		free(string);	
	}

	return 0;


}


