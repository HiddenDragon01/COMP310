struct CPU {int IP; char IR[1000]; int quanta;};


int run (int quanta);
