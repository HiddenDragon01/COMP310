#include<stdio.h>
#include<stdlib.h>
#include<string.h>	
#include "kernel.h"

		
	

	void addToRAM(FILE *p, int *start, int *end) {

		int index = 0;

		while (ram[index] != NULL) {
			index++;
		}

		*start = index;
		
		char buffer[1000];
		while (fgets(buffer, 1000, p)) {
					
			ram[index++] = strdup(buffer);

			if (index > 1000) {
				printf("ERROR: Not enough RAM to add program.");
				*start = -1;
				return;
			}

		}
		index--;	
		*end = index;
			
		fclose(p);

	}


