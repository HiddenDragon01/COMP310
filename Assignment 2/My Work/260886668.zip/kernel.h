int myinit(char *filename);
int scheduler();
char *ram[1000];
struct rQueue {

        struct PCB* curPCB;
        struct rQueue* next;
        struct rQueue* prev;

};
struct rQueue* head;
struct rQueue* tail;
struct CPU *cp;

