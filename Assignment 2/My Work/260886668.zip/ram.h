void addToRAM(FILE *p, int *start, int *end);
