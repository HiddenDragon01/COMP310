#include<stdio.h>
#include<stdlib.h>
#include "pcb.h"
#include "cpu.h"
#include "shell.h"
#include "ram.h"

struct rQueue {
	
	struct PCB* curPCB;
	struct rQueue* next;
	struct rQueue* prev;

};

struct rQueue* head;
struct rQueue* tail;
char *ram[1000];
struct CPU *cp;

void addToReady(struct PCB* cur) {
	
	
	if ((head)->curPCB == NULL) {
		
		(head)->curPCB = cur;
		(tail)->curPCB = cur;
		return;
	}


        struct rQueue* new = (struct rQueue*)malloc(sizeof(struct rQueue));

        new->curPCB = cur;

        new->next = tail;

        new->prev = NULL;

	(tail)->prev = new;

	tail = new;

	if (head->prev == NULL) {
		head->prev = tail;
	}



}

int myinit(char *filename) {
	FILE *x = fopen(filename, "r");

	if (x == NULL) {
		return 1;
	}

	int *start;
	int *end;
	start = (int *)malloc(sizeof(int));
	end = (int *)malloc(sizeof(int));
	addToRAM(x, start, end);
	if (*start == -1) {
		return 1;
	}

	struct PCB* newPCB = makePCB(*start, *end);
	addToReady(newPCB);
	return 0;

}

int scheduler() {

        cp->IP = (head)->curPCB->PC;

	run (cp->quanta);
	
	return 0;

}



int main() {
	
	 // Data Structures:

        head = (struct rQueue*)malloc(sizeof(struct rQueue));
        tail = (struct rQueue*)malloc(sizeof(struct rQueue));
        cp = (struct CPU*)malloc(sizeof(struct CPU)); 
	
	cp->quanta = 2;

	shellUI();


	free(head);
	// Tail = Head at end
	free(cp);
	return 0;
}
