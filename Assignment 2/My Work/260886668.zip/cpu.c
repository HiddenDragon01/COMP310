#include<stdio.h>
#include<stdlib.h>
#include "ram.h"
#include "interpreter.h"
#include "kernel.h"
#include "pcb.h"
#include "shell.h"
#include "stdlib.h"
#include "string.h"

struct CPU {int IP; char *IR[1000]; int quanta;};




int run(int quanta) {
	

	int bef = cp->IP;
	cp->IP = cp->IP + quanta;
	int aft = cp->IP;

	// Run for quanta lines of code
	for (int i = bef; i < aft; i++){
		
		if ((head)->curPCB->end < i) {
			break;
		}
		
		char *s = malloc(256); 
		memset( s, 0x00, 256);
	 	s = ram[i];
		parse(s, cp->IR);

		if (cp->IR[0] == NULL) {
			printf("Unknown command\n");
			continue;
		}


		interpreter(cp->IR);	
	}		
	if ((head)->curPCB->end > aft - 1) {
		(head)->curPCB->PC = cp->IP;	
		// Check if CPU is available
		if ((head)->prev != NULL) {
			head = (head)->prev;
			(tail)->prev = (head)->next;
			(head)->next->next = tail;
			(head)->next->prev = NULL;
			tail = (head)->next;
			(head)->next = NULL;
		
		}
		scheduler();
		return 0;	
			
			
	} else 

                                {
				

                                for (int i = (head)->curPCB->start; i <= (head)->curPCB->end; i++) {
                                        ram[i] = NULL;


                                }

				if ((head)->prev == NULL) {
						
						memset(head, 0x00, sizeof(head));
						memset(cp, 0x00, sizeof(cp));
                                                return 0;
			       }
				head = (head)->prev;
				memset(head->next, 0x00, sizeof(head->next));
				free((head)->next);
				scheduler();
				return 0;
        } 

}
