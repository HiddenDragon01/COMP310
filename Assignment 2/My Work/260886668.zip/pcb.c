#include<stdio.h>
#include<stdlib.h>

struct PCB {int PC; int start; int end;};


struct PCB* makePCB(int start, int end) {

	struct PCB *PCBP = malloc (sizeof (struct PCB));
	
	PCBP->PC = start;
	PCBP->start = start;
	PCBP->end = end;

	return PCBP;


}
