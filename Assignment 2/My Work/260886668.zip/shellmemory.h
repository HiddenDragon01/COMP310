int memindex;
void allocateMemory();

void StoreMemory(char *a, char *b);

void printVariable(char *a);
