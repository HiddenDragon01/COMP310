void interpreter(char *arr[]);
