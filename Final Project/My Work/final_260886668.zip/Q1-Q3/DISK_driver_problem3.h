//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    DISK_driver_problem3.h
//

int seekExam(int activeFileIndex, int offset);
