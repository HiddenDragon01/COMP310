//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    DISK_driver_problem1.h
//

int openFileExam(int activeFileIndex, char *name);
char *readBlockExam(int activeFileIndex);
int writeBlockExam(int activeFileIndex, char *data);
