//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    interpreter.h
//

#ifndef interpreter_h
#define interpreter_h

#pragma mark Interpreter Entry Point
int interpreter(char *parsedCommand[]);

#endif /* interpreter_h */
