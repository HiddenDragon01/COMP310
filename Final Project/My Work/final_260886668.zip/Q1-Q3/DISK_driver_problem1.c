//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    You need to fill in this file for the first problem
//

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include "DISK_driver.h"
#include "DISK_driver_problem1.h"

int openFileExam(int activeFileIndex, char *name) {
   
    // Ensure that the file has not already been opened
    if (active_file_table[activeFileIndex] != NULL) {

       printf("ERROR: Index number in use.\n");
       return -1;
   }	    

    // Checking if there is a free block in the data section to create a new file
    if(currentPartition.last_free_block > currentPartition.total_blocks)
        return -1;

    // Lookup on the FAT
    int FATindex = 0;
    for (; FATindex < MAX_FILES; FATindex++)
        if (fat[FATindex].filename == NULL || strcmp(fat[FATindex].filename, name) == 0)
            break;

    // Checking if the file is not already open
    int i = 0;
    for (; i < MAX_OPENFILES; i++)
        if(active_file_table_owners[i] == FATindex)
            return FATindex;

    // Opening the partition file
    if(activeFileIndex == MAX_OPENFILES)
        return -1; // Too many files open at the same time

    active_file_table[activeFileIndex]  = fopen(filename, "r+");
    active_file_table_owners[activeFileIndex] = FATindex;

    if(FATindex == MAX_FILES && fat[MAX_FILES -1].filename != NULL){
        // File DNE on the FAT and FAT is full
        fclose(active_file_table[activeFileIndex]);
        active_file_table[activeFileIndex] = NULL;
        active_file_table_owners[activeFileIndex] = -1;

        return -1;
    }
    else if(fat[FATindex].filename == NULL){
        // Make a new file
        fat[FATindex].filename = malloc(sizeof(500));
        strcpy(fat[FATindex].filename, name);
        fat[FATindex].current_location = 0;
        fat[FATindex].file_length = 0;

        // READ:
        // ALL Seeking is done when doing IO, since the file system is NOT contigous and files do not have a pre-allocated size.
        // Space in the data section will be allocated ON WRITE, so we are done here

        // Seeking to the data section
        //fseekToDataSection(active_file_table[activeFileIndex]);
        // Seeking to first block
    }
    else{

        // Open a current file
        // Data structures already initialized
        fat[FATindex].current_location = 0;

        // READ:
        // ALL Seeking is done when doing IO, since the file system is NOT contigous and files do not have a pre-allocated size.

        // Seeking to the data section
        //fseekToDataSection(active_file_table[activeFileIndex]);
        // Seeking to first block

    }

    return FATindex;


}

char *readBlockExam(int activeFileIndex){
	

    int file = active_file_table_owners[activeFileIndex];


    if(file < 0)
        return NULL; // File open opreation probably failed before this call. We should never get here.

    if(fat[file].current_location >= MAX_BLOCKS)
        return NULL;

    // Lookup the block to read from
    int blockToRead = fat[file].blockPtrs[fat[file].current_location];

    // Seeing the block is valid
    if(blockToRead == -1)
        return NULL;

    // Get the file pointer
    FILE *filePtr = active_file_table[activeFileIndex];


    // Seek to the block
    fseekToBlock(filePtr, blockToRead);
	
    fseek(filePtr, seek_file[activeFileIndex], SEEK_CUR);

    // Reading the block char by char into the buffer
    int i = 0;
    for (; i < currentPartition.block_size; i++) {
        char c = fgetc(filePtr);
        if(c == '0'){
            blockBuffer[i] = '\0';
            break;
        }
        blockBuffer[i] = c;
    }
    blockBuffer[i] = '\0';

    fat[file].current_location += 1;

    return blockBuffer;

}

int writeBlockExam(int activeFileIndex, char *data){

    int file = active_file_table_owners[activeFileIndex];

    if(file < 0)
        return 0; // File open opreation probably failed before this call. We should never get here.
    
    if(fat[file].current_location >= MAX_BLOCKS)
        return 0; // No more blocks are available for the file
    
    // Appending by default
    fat[file].current_location = fat[file].file_length;
    
   // Get the file pointer
    FILE *filePtr = active_file_table[activeFileIndex];
	
    // Seek to next free block
    fseekToNextFreeBlock(filePtr);
    
    // Now seek by the amount at the corresponding entree in the seek_file array
    fseek(filePtr, seek_file[activeFileIndex], SEEK_CUR);

    // Writing the block char by char into the buffer
    for (int i = 0; i < currentPartition.block_size; i++) {
        char c = *(data+i);
        if(c == 0)
            c = '0';
        fputc(c, filePtr);
    }
    
    // Updating the file's blockPtr array
    fat[file].blockPtrs[fat[file].current_location] = currentPartition.last_free_block;
    
    currentPartition.last_free_block += 1;
    fat[file].current_location += 1;
    fat[file].file_length +=1;
    if(fat[file].current_location < MAX_BLOCKS)
        fat[file].blockPtrs[fat[file].current_location] = -1;
    
    // Update the FAT on disk
    partitionFile = fopen(filename, "r+");
    updateFATOnDisk();
    fclose(partitionFile);
    
    return 1;
}





