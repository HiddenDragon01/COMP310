//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    readme.txt for Q1-3
//

To get the executable, mykernel, type "chmod u+x recompile.sh" and "./recompile.sh."

For Q3, I created the "seek_file" array to account for seeks by some active file table index. This array is initialized to 0, modified when seek is called, and used during read and write.

