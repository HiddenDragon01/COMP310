//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    You need to fill in this file for the third problem
//

#include<stdio.h>

#include "DISK_driver.h"
#include "DISK_driver_problem1.h"
#include "DISK_driver_problem2.h"
#include "DISK_driver_problem3.h"

int seekExam(int activeFileIndex, int offset) {

	int file = active_file_table_owners[activeFileIndex];
	
	// Make sure the offset is not out of bounds
	if (offset > fat[file].file_length * currentPartition.block_size - seek_file[activeFileIndex]) {

		printf("ERROR: Out of bounds. Stopped at end of file.\n");
		seek_file[activeFileIndex] = fat[file].file_length * currentPartition.block_size;
		return -1;
	}

	if (offset < seek_file[activeFileIndex]) {
		printf("ERROR: Out of bounds. Stopped at start of file.\n");
		return -1;
	}


	// Else, store the offset in the seek_file array at the active file index number
	seek_file[activeFileIndex] = offset;		
	return 0;


}
