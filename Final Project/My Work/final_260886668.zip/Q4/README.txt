//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    readme.txt for Q4
//

To get the executable, mykernel, type "chmod u+x recompile.sh" and "./recompile.sh."

