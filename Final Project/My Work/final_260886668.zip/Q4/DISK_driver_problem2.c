//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    You need to fill in this file for the second problem
//

#include<stdio.h>

#include "DISK_driver.h"
#include "DISK_driver_problem1.h"
#include "DISK_driver_problem2.h"


int closeFileExam(int activeFileIndex) {
	
	// Check if the entree is not active. If so, there is nothing to close
	if (active_file_table[activeFileIndex] == NULL) {
		printf("ERROR: Index number not in use.\n");
		return -1;
	}
        
	// Else, close the file and set the active file table and the active file table owners entrees to NULL and -1, respectively
	fclose(active_file_table[activeFileIndex]);
	active_file_table[activeFileIndex] = NULL;
	active_file_table_owners[activeFileIndex] = -1;
	return 0;


}





