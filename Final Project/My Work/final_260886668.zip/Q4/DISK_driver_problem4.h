//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    DISK_driver_problem4.h
//
int chmodExam(int activeFileIndex, char* read, char* write);
