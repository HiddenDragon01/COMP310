//    Final Project COMP 310
//    Your Name: Ryan Sowa
//    Your McGill ID: 260886668
//
//    You need to fill in this file for the fourth random problem



//	  Fill in the name of the command that you are implementing here 
//    ------------------>chmod_EXAM<-----------------------------

#include<stdio.h>
#include<string.h>

#include "DISK_driver.h"
#include "DISK_driver_problem1.h"
#include "DISK_driver_problem2.h"
#include "DISK_driver_problem3.h"
#include "DISK_driver_problem4.h"

int chmodExam(int activeFileIndex, char* read, char* write) {
 

    int file = active_file_table_owners[activeFileIndex];
 	
	
    // Check syntax
    if (read == NULL || write == NULL) {
	printf("ERROR: Bad syntax.\n");
	return 1;
    }
    

    // Recognized commands, set read and write permissions correspondingly
    if (strcmp(read, "r+") == 0) {
	    fat[file].read = true;
    }
    
    else if (strcmp(read, "r-") == 0) {
            fat[file].read = false;
    }

    if (strcmp(write, "w+") == 0) {
            fat[file].write = true;
	    return 0;
    }
	
    else if (strcmp(write, "w-") == 0) {
            fat[file].write = false;
	    return 0;
    }

   // Else, print error
    printf("ERROR: Bad syntax.\n");
    return -1;






}
