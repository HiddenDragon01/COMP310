// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2021


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "ram.h"
#include "interpreter.h"
#include "kernel.h"
#include "pcb.h"
#include "shell.h"
#include "memorymanager.h"



// Define CPU struct with relevant fields
struct CPU {int IP; char *IR[1000]; int quanta; int offset;};

// Update the PCB which holds a reference to the frame replaced
void updateVictimPCB(int replaceFrame) {

	struct rQueue* cur = head;
	
	// Search all the PCB's to find which one holds a reference to the frame replaced
	while (cur != NULL) {
		
		for (int i = 0; i < 10; i++) {

				if (cur->curPCB->pageTable[i] == replaceFrame) {

	
					cur->curPCB->pageTable[i] = -1;
					return;

				}

		}
		
		cur = cur->prev;
	}	
	



}


// Run the current PCB for one quanta (unless page fault occurs)
int run(int quanta) {
	
	
	int bef = cp->IP + head->curPCB->PC_offset;
	int aft = bef + quanta;
	cp->offset = head->curPCB->PC_offset;

	// Run for quanta lines of code starting from IP + offset - If offset = 4, then stop execution
	for (int i = bef; i < aft && cp->offset < 4; i++){
		
		char *s = malloc(256); 
		memset( s, 0x00, 256);
	 	s = ram[i];
		// If ram is NULL at index i, that means at end of program 	
		if (ram[i] == NULL) {
			cp->offset = 4;
			break;
		}

		parse(s, cp->IR);
		
		if (cp->IR[0] == NULL) {
			printf("Unknown command\n");
			continue;
		}


		interpreter(cp->IR);

		cp->offset++;	
	}	
	
	// Check if there exists a page fault
	if (cp->offset == 4) {
		
		head->curPCB->PC_page++;

	       	if (head->curPCB->PC_page >= head->curPCB->pages_max) {
			// Terminate program if beyond pages max
			if ((head)->prev == NULL) {

                                                memset(head, 0x00, sizeof(head));
                                                memset(cp, 0x00, sizeof(cp));
						memset(ram, 0x00, sizeof(ram));
                                                return 0;
                       	}
			
                       	head = (head)->prev;
                       	memset(head->next, 0x00, sizeof(head->next));
                       	free((head)->next);
                       	scheduler();
                      	return 0;


		} else {

			// If found frame in page table
			if ((head->curPCB)->pageTable[head->curPCB->PC_page] != -1) {

				cp->IP = (head->curPCB)->pageTable[head->curPCB->PC_page];	
			
			// If did not find frame in page table

			} else {


				// open PCB file
				FILE *f = fopen(head->curPCB->filePath, "r");
				

				if (f == NULL) {
					printf("Could not open file\n");
					return 1;
				}

				// Find space in ram

				int frame = findFrame();

				// If no room, find a frame to replace and load the page into that frame. Then, update the current PCB and the victim PCB's page tables. 
				// Change the instruction pointer to this frame
        	        	if (frame == -1) {
        	                	int victimFrame = findVictim(head->curPCB);
					loadPage(head->curPCB->PC_page, f, victimFrame);
                	        	updatePageTable(head->curPCB, head->curPCB->PC_page, victimFrame, victimFrame);
					updateVictimPCB(victimFrame);
					cp->IP = victimFrame;

				// If there is room, then load the page, update the page table, and update the instruction pointer.	

               		 	} else {
					
                        		loadPage(head->curPCB->PC_page, f, frame);
	                        	updatePageTable(head->curPCB, head->curPCB->PC_page, frame, -1);
					cp->IP = frame;

                		}

			}

			// Change offset to 0 since we are at the start of the frame now

			cp->offset = 0;


		}

		// Move PCB to tail of ready list
		(head)->curPCB->PC = cp->IP;
                (head)->curPCB->PC_offset = cp->offset;
                // Check if CPU is available
                if ((head)->prev != NULL) {
                        head = (head)->prev;
                        (tail)->prev = (head)->next;
                        (head)->next->next = tail;
                        (head)->next->prev = NULL;
                        tail = (head)->next;
                        (head)->next = NULL;

                }
                scheduler();
                return 0;

	}

	else {
		(head)->curPCB->PC = cp->IP;
		(head)->curPCB->PC_offset = cp->offset;	
		// Check if CPU is available
		if ((head)->prev != NULL) {
			head = (head)->prev;
			(tail)->prev = (head)->next;
			(head)->next->next = tail;
			(head)->next->prev = NULL;
			tail = (head)->next;
			(head)->next = NULL;
		
		}
		scheduler();
		return 0;	
			
			
	}  

				

         

}
