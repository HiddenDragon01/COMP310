// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


void interpreter(char *arr[]);
