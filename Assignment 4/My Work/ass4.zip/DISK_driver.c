// Name: Ryan Sowa
// ID: 260886668
// Date: April 7, 2021

#include<stdio.h>
#include<stdlib.h>
#include<string.h>

// Declare necessary data structures

struct PARTITION {
	int total_blocks;
 	int block_size;
	char* name;
	int maximum_block_occupied;
} partitionStruct;

struct FAT {
 	char *filename;
 	int file_length;
	int blockPtrs[10];
 	int current_location;
} fat[20];

char *block_buffer = "";

int block_buffer_index = 0;
int string_index = 0;


FILE *active_file_table[5];
char* activeFat[5];

// Look for a block which has not been written yet
int findFreeBlock(){
	
	FILE *x = fopen(partitionStruct.name, "r+");
        char currentLine[1000];
	
	
	 while(fgets(currentLine, 1000, x)) {

                if (strstr(currentLine, "DATA SECTION:\n") != NULL) {


			char c = fgetc(x);
			int count = 0;

			while (c != '0' || (count % partitionStruct.block_size != 0)) {

				count++;
				c = fgetc(x);
			}

			return count;
		}
	

	 }

}






// Update the FAT in the partition table with accurate information 
void updateFAT(int fatIndex) {
	
	FILE* dup = fopen("duplicateFile", "w");
	FILE* x = fopen(partitionStruct.name, "r");

	char currentLine[1000];

	while(fgets(currentLine, 100, x)) {


		if (strstr(currentLine, "maximum blocks occupied:\n") != NULL) {

                        fprintf(dup, "%s", currentLine);
			fgets(currentLine, 100, x);
			fprintf(dup, "%d\n", partitionStruct.maximum_block_occupied);
			fgets(currentLine, 100, x);

                }
	
		fprintf(dup, "%s", currentLine);

		if (strstr(currentLine, "file:\n") != NULL) {
				
			fgets(currentLine, 100, x);
			fprintf(dup, "%s", currentLine);

			if (strstr(currentLine, fat[fatIndex].filename) != NULL) {
				
                                fgets(currentLine, 100, x);
				fprintf(dup, "%s", currentLine);
				fgets(currentLine, 100, x);
                                fprintf(dup, "%d\n", fat[fatIndex].file_length);
				fgets(currentLine, 100, x);
				fprintf(dup, "%s", currentLine);
				fgets(currentLine, 100, x);

				for (int i = 0; i < 10; i++) {

					if (fat[fatIndex].blockPtrs[i] != -1) {
						
						fprintf(dup, "%d\n", fat[fatIndex].blockPtrs[i]);


					} else {
						break;
					}

				}

				while (strstr(currentLine, "current location:\n") == NULL) {
					fgets(currentLine, 100, x);
				}  

				fprintf(dup, "%s", currentLine);	


                        }
				

		}	

		

    	}

	char command[50];
	strcpy(command, "mv duplicateFile ");
	strcat(command, partitionStruct.name);
	system(command);
	fclose(x);
	fclose(dup);	




}




// initialize all global data structure and variables to zero or null. Called from your boot() function.
void initIO() {
	
	memset(fat, 0x00, sizeof(fat));

	memset(block_buffer, 0x00, sizeof(block_buffer));
	
	block_buffer_index = 0;
	string_index = 0;

}

//create & format partition. Called from your mount() function that lives in the interpreter, associated to your scripting mount command
int partition(char *name, int blocksize, int totalblocks) {
	
	 // Command to make PARTITION directory if it does not exist already
        char command[50];
        strcpy(command, "mkdir -p PARTITION");
        system(command);

	// Write the partition info into the partition file
        FILE *x = fopen(name, "w");

	fprintf(x, "--------------------------------------------------------------------------------------------------------\n");
        fprintf(x, "PARTITION:\n");
        fprintf(x, "total blocks:\n%d\n", totalblocks);
        fprintf(x, "block size:\n%d\n", blocksize);
	fprintf(x, "maximum blocks occupied:\n-1\n");
        fprintf(x, "--------------------------------------------------------------------------------------------------------\n");
        fprintf(x, "FAT:\n");
        fprintf(x, "--------------------------------------------------------------------------------------------------------\n");
        fprintf(x, "DATA SECTION:\n");


        for (int i = 0; i < totalblocks*blocksize; i++) {

                fprintf(x, "0");
        }
	
	fprintf(x, "\n");

	fclose(x);



        return 1;



}


// load FAT & create buffer_block. Called from your mount() function that lives in the interpreter, associated to your scripting mount command.
int mountFS(char *name) {
	
	// initialize fat, active file table, and activeFat

	memset(fat, 0x00, sizeof(fat));

	memset(active_file_table, 0x00, sizeof(active_file_table));

        memset(activeFat, 0x00, sizeof(activeFat));

	partitionStruct.name = name;

	char currentLine[1000];

	FILE *x = fopen(name, "r");

	int fatIndex = 0;

	// Now, look for information in the FAT and partition to load into our data structures. 
	 while(fgets(currentLine, 1000, x)) {
		
                if (strstr(currentLine, "total blocks:\n") != NULL) {

                        fgets(currentLine, 1000, x);
                        int total_blocks;
                        sscanf(currentLine, "%d", &total_blocks);
			partitionStruct.total_blocks = total_blocks;

                }

                else if (strstr(currentLine, "block size:\n") != NULL) {

                        fgets(currentLine, 1000, x);
                        int block_size;
                        sscanf(currentLine, "%d", &block_size);
			partitionStruct.block_size = block_size;

			// Allocate block_size memory for the block buffer
			block_buffer = malloc(block_size);


                }

		else if (strstr(currentLine, "maximum blocks occupied:\n") != NULL) {

                        fgets(currentLine, 1000, x);
                        int max_blocks;
                        sscanf(currentLine, "%d", &max_blocks);
                        partitionStruct.maximum_block_occupied = max_blocks;

                }

		else if (strstr(currentLine, "file:\n") != NULL) {
			
                        fgets(currentLine, 1000, x);
                       	currentLine[strcspn(currentLine, "\n")] = 0;
			
			if (fat[fatIndex].filename == NULL) {
				fat[fatIndex].filename = malloc(100);
			}

                      	strcpy(fat[fatIndex].filename, currentLine);


                }

		else if (strstr(currentLine, "file length:\n") != NULL) {

                        fgets(currentLine, 1000, x);
			int file_length;
                        sscanf(currentLine, "%d", &file_length);
                        fat[fatIndex].file_length = file_length;


                }

		else if (strstr(currentLine, "block pointers:\n") != NULL) {

			fgets(currentLine, 1000, x);
			int blockIndex = 0;
			
			while (strstr(currentLine, "current location:\n") == NULL) {

				int block;
                        	sscanf(currentLine, "%d", &block);
                        	fat[fatIndex].blockPtrs[blockIndex++] = block;

                            	fgets(currentLine, 100, x);
                      	}

			while (blockIndex < 10) {
				
				fat[fatIndex].blockPtrs[blockIndex++] = -1;

			}
			
			fgets(currentLine, 1000, x);


			// If file length is 0, then reset current location and the first block pointer
			if (fat[fatIndex].file_length == 0) {
				
				int freeBlock = findFreeBlock();
				fat[fatIndex].blockPtrs[0] = freeBlock;
				fat[fatIndex++].current_location = freeBlock;

			}

			else {

                        	fat[fatIndex].current_location = fat[fatIndex].blockPtrs[0];
				fatIndex++;
			}

		}



        }

	fclose(x);
	return 1;


}


// find filename or creates file if it does not exist, returns file’s FAT index. Called from your scripting read and write commands in interpreter
int openfile(char *name) {
	
	memset(block_buffer, 0x00, sizeof(block_buffer));
	
	block_buffer_index = 0;

	string_index = 0;

	FILE *x = fopen(partitionStruct.name, "rw");
	
	// Iterate through fat entries to see if file was created
        for (int i = 0; i < 20; i++) {
		
		// If the file was not created, create the file with accurate information
                if (fat[i].filename == NULL) {
			
			for (int j = 1; j < 10; j++) {
				fat[i].blockPtrs[j] = -1;
			}

                        fat[i].filename = name;
			int freeBlock = findFreeBlock();
			fat[i].blockPtrs[0] = freeBlock;
			fat[i].current_location = freeBlock;

                        FILE* dup = fopen("duplicateFile", "w");

                        char currentLine[1000];
                        while(fgets(currentLine, 100, x)) {

                                fprintf(dup, "%s", currentLine);

                                if (strstr(currentLine, "FAT:\n") != NULL) {
                                        fprintf(dup, "file:\n%s\n", name);
                                        fprintf(dup, "file length:\n0\n");
					fprintf(dup, "block pointers:\n%d\n", freeBlock);
                                        fprintf(dup, "current location:\n%d\n", freeBlock);
                                }

                        }
			
			partitionStruct.maximum_block_occupied += (partitionStruct.block_size*10);
			
			// If taken up the whole data section, then report too many files
			if (partitionStruct.maximum_block_occupied > partitionStruct.total_blocks * partitionStruct.block_size) {

				printf("Too many files!\n");
				return -1;
			}

                        char command[50];
                        strcpy(command, "mv duplicateFile ");
                        strcat(command, partitionStruct.name);
                        system(command);
			fclose(x);
			fclose(dup);

			// Update the FAT to report the change in maximum blocks occupied
			updateFAT(i);

                        return i;

                }
		

		// If file exists in fat, then if it is not already in the active file table, open it, seek to the first block, and add it to the file table
                if (strcmp(fat[i].filename, name) == 0) {


                        char currentLine[1000];

                	while(fgets(currentLine, 100, x)) {

                        	if (strstr(currentLine, "DATA SECTION:\n") != NULL) {
                                	fseek(x, fat[i].blockPtrs[0], SEEK_CUR);
                                	break;
                        	}
                	}

			for (int j = 0; j < 5; j++) {

				
				if (activeFat[j] != NULL && strcmp(activeFat[j], name) == 0) {
					fclose(x);
					return i;
				}
			
                                if (active_file_table[j] == NULL) {
                                        active_file_table[j] = x;
                                        activeFat[j] = name;
					fclose(x);
                                        return i;
                                }

				if (j == 4) {

                                        printf("Active file table full!\n");
                                        fclose(x);
                                        return -1;
                                }


                        }


                }

        }
	
	printf("No space in FAT table!\n");
	fclose(x);
        return -1;

}



// using the file FAT index number, load buffer with data from current_location. Return block data as string from block_buffer.
char* readBlock(int file) {
	
	// Check if current_location is beyond the end of the file. Else, initialize it to the correct value

	if (file == -1) {
		printf("Error opening the file!\n");
		return "error";
	}
	
	int max = -1;

	for (int i = 0; i < 10; i++) {
		
		if (fat[file].blockPtrs[i] > max) {
			max = fat[file].blockPtrs[i];
		}

	}

	if (fat[file].current_location > max) {
		
	 	block_buffer[block_buffer_index] = '\0';
               	return block_buffer;	
	}	

	for (int i = 0; i < 10; i++) {

		
		// If at the end of file, return the block buffer
		if (fat[file].blockPtrs[i] == -1 || fat[file].file_length == 0) {
			
			int freeBlock = findFreeBlock();
			fat[file].current_location = freeBlock;
			block_buffer[block_buffer_index] = '\0';
                       	return block_buffer;
		}
		
		if (strlen(block_buffer) == 0) {
			
			break;

		}

		if (fat[file].blockPtrs[i] == fat[file].current_location && fat[file].blockPtrs[i+1] != -1) {
			

			fat[file].current_location = fat[file].blockPtrs[i+1];
			break;

		}

	}
	
	 // write a block into the block buffer
        FILE *x = fopen(partitionStruct.name, "r");
        char currentLine[1000];

       	while(fgets(currentLine, 1000, x)) {


              	if (strstr(currentLine, "DATA SECTION:\n") != NULL) {

                  	fgets(currentLine, 1000, x);
			
			int init = fat[file].current_location;
			
			// Loop "block" number of times to store appropriate data in the block
			for (int i = init; i < fat[file].current_location + partitionStruct.block_size; i++) {

				block_buffer[block_buffer_index++] = currentLine[i];
			}		
			
		
			break;	


            	}

  	}	
	
	// If not at the end of the file, then return "keep reading"
	
	fclose(x);	
	return "keep reading";
	


}

// using the file FAT index number, write data to disk at current_location
int writeBlock(int file, char *data) {
	

	// If at the end of the file, return as no more characters can be written
	if (fat[file].file_length >= 10) {
		printf("At the end of the file!\n");
		fat[file].current_location += partitionStruct.block_size;
		updateFAT(file);
                return 1;
        }
	
	FILE *x = fopen(partitionStruct.name, "r+");
        char currentLine[1000];

	// Else, write "block_size" number of characters at current_location
        while(fgets(currentLine, 1000, x)) {
		
                if (strstr(currentLine, "DATA SECTION:\n") != NULL) {
			
			// Initialize current_location with the correct value
			
			int set = -1;	

			for (int i = 0; i < 9; i++) {
				
				if (fat[file].file_length == 0) {
                                        break;
                                }	

				if (fat[file].blockPtrs[i+1] == -1) {
					
					set = i+1;
					break;
				}
			

				if (fat[file].blockPtrs[i] == fat[file].current_location) {
					
					fat[file].current_location = fat[file].blockPtrs[i+1];
					break;
				}

			}

			if (set != -1) {
				
				int freeBlock = findFreeBlock();
				fat[file].current_location = freeBlock;
				fseek(x, freeBlock, SEEK_CUR);
				fat[file].blockPtrs[set] = freeBlock;
				
			} else {

				fseek(x, fat[file].current_location, SEEK_CUR);

			}

		
			int init = fat[file].current_location;

			fat[file].file_length++;

                        for (int i = init; i < fat[file].current_location + partitionStruct.block_size; i++) {
				
				fprintf(x, "%c", data[string_index++]);				

				// If have finished writing data, then update the FAT the new file length and return
				if (string_index == strlen(data)) {

					fclose(x);
					int freeBlock = findFreeBlock();
                                        fat[file].current_location = freeBlock;
					updateFAT(file);
					return 1;

				}

		
                        }


                        break;


                }

        }

        fclose(x);
        return 0;


}




