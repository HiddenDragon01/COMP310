// Name: Ryan Sowa
// ID: 260886668
// Date: April 7, 2021

void initIO();
int partition(char *name, int blocksize, int totalblocks);
int mountFS(char *name);
int openfile(char *name);
char* readBlock(int file);
int writeBlock(int file, char *data);
