// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2021



// Define CPU struct and run function

struct CPU {int IP; char IR[1000]; int quanta; int offset;};


int run (int quanta);


