// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2021

// Define the PCB struct and the makePCB function

struct PCB {int PC; int pageTable[10]; int PC_page; int PC_offset; int pages_max; char *filePath;};
struct PCB* makePCB();
