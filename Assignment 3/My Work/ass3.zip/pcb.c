// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


#include<stdio.h>
#include<stdlib.h>

struct PCB {int PC; int pageTable[10]; int PC_page; int PC_offset; int pages_max; char *filePath;};

// Malloc a PCB, and initialize all page table entries to -1 (as a placeholder)
struct PCB* makePCB() {
	

	struct PCB *PCBP = malloc (sizeof (struct PCB));
	
	// Initialize all entries of array with -1
	for (int i = 0; i < 10; i++) {

		PCBP->pageTable[i] = -1;
	}


	return PCBP;


}

