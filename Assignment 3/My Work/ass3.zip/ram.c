// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


#include<stdio.h>
#include<stdlib.h>
#include<string.h>	
#include "kernel.h"
#include "memorymanager.h"
#include "pcb.h"	
	
	// Open the file and launch it (which will add it to ram) 
	void addToRAM(char *fileName, struct PCB* new) {
		

		FILE *x = fopen(fileName, "r");

        	if (x == NULL) {
			printf("Could not open file\n");
                	return;
        	}
		
		launcher(x, fileName, new);

	}


