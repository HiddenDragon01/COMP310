// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020

// Define shell memory tools

int memindex;
void allocateMemory();

void StoreMemory(char *a, char *b);

void printVariable(char *a);
