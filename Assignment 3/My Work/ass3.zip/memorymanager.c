// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "pcb.h"
#include "kernel.h"


// Checks to see if any PCB's are currently pointing to replaceFrame
int checkPCBs(int replaceFrame) {

        struct rQueue* cur = head;

        // Search all the PCB's to find one which is running the frame replaced
        while (cur != NULL) {

		if (cur->curPCB->PC == replaceFrame) {
			return 0;
		}	


                cur = cur->prev;
        }

	return 1;




}



// Returns total number of pages needed by program
int countTotalPages(FILE *f) {

	int pages = 0;
	int count = 0;
	char c;
	
	while(!feof(f)) {
  		c = fgetc(f);
  		if(c == '\n') {

    			count++;

			if (count % 4 == 0) {
				pages = count/4;
				
			} else {
				pages = (count/4) + 1;
			}
			
  		}
	}

	return pages;
}

// Loads 4 lines of code from the page into the frame in ram
void loadPage(int pageNumber, FILE *f, int frameNumber) {

	char buffer[1000];
	int index = 0;
	int count = 0;

	while (fgets(buffer, 1000, f)) {
		

		if (pageNumber*4 > count) {
			count++;
			continue;
		}

		ram[frameNumber + index++] = strdup(buffer);
		
		

		if (index == 4) {
			return;
		}	
		

	}

	while(index < 4) {
		

		ram[frameNumber + index++] = NULL;
	}

	return;
}



// Use FIFO technique to search ram for a frame 
// If one exists, then return its index number. Else, return -1
int findFrame() {
	
	for (int i = 0; i < 40; i += 4) {

		if (ram[i] == NULL) {
			return i;
		}

	}

	return -1;


}


// Use random number generator to pick a frame number
// If the frame number does not belong to the pages of the active PCB, then return that frame number
// Else, increment frame number until come to one not in PCB's pages and return that number
int findVictim(struct PCB* p) {
	
	// Generate a random multiple of 4 from 0 to 39
	int randNum = abs((rand() * 4 ) % 40);
	
	
	// Ensure that PCB does not contain this frame in its page table and this frame is not pointed to by any other PCB's
	while (1) {

		for (int i = 0; i < 10; i++) {

			if ((p->pageTable[i]) == randNum) {
				
				break;
			}

			if (i == 9) {

				// Check if any other PCB's are pointing to randNum
                                if (checkPCBs(randNum) == 1) {
                                        return randNum;
                                }
	
			}

		}

		randNum = (randNum + 4) % 40;
	}
}

// Ask for page fault
// If a victim was selected, update PCB page table of the victim
int updatePageTable(struct PCB* p, int pageNumber, int frameNumber, int victimFrame) {

	if (victimFrame == -1) {

		(p->pageTable[pageNumber]) = frameNumber;

	} else {
		
		(p->pageTable[pageNumber]) = victimFrame;
	
	}

	return 0;

}

// Memory manager launches programs that execute via exec, manages frames, and manages paging

// Returns a 1 if successful launching the program. Else, returns a 0
// Copies entire file into Backing Store
// Close file pointer pointing to original file
// Open the file in the Backing Store
// Load two pages of the program into RAM (page = 4 lines)
int launcher (FILE *p, char *fileName, struct PCB* cur) {

        // Command to copy to BackingStorage
        char command[50];

	char* command1 = "cp ";
	char* command3 = " BackingStorage";

	char* fullCommand;
	fullCommand = malloc(256);
        memset(fullCommand, 0x00, 256);	
	strcpy(fullCommand, command1);
	strcat(fullCommand, fileName);
	strcat(fullCommand, command3);

        strcpy(command, fullCommand);

        system(command);
	
	free(fullCommand);

        fclose(p);

        // TODO: Open the file, get the file pointer, p
	
	char* path = "./BackingStorage/";

        char* full;
        full = malloc(256);
	memset(full, 0x00, 256);
        strcpy(full, path);
	strcat(full, fileName);
	
	FILE *x = fopen(full, "r");
	
	if (x == NULL) {
		printf("Could not open file");
		return 1;

	}
	
	cur->filePath = full;


   	int totalPages = countTotalPages(x);
	rewind(x);

	int frame = findFrame();
	cur->PC = frame;

	// Find an empty frame, load a page into that frame, and update the PCB's page table
	for (int i = 0; i < 2 && i  < totalPages; i++) {

                frame = findFrame();
                loadPage(i, x, frame);
		rewind(x);
                updatePageTable(cur, i, frame, -1);
		rewind(x);


	}
	
	
	cur->pages_max = totalPages;
	cur->PC_page = 0;
	cur->PC_offset = 0;

	fclose(x);
	return 0;

}


