// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020

Type "make" to obtain the executable, mykernel.
Type "make clean" to remove the executable and object files.

In addition to testfile.txt, please download files 1.txt, 2.txt, and 3.txt which are called by testfile.txt.
