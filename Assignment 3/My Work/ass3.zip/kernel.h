// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020

// Define functions and necessary data structures

int myinit(char *filename);
int scheduler();
char *ram[40];
struct rQueue {

        struct PCB* curPCB;
        struct rQueue* next;
        struct rQueue* prev;

};
struct rQueue* head;
struct rQueue* tail;
struct CPU *cp;

