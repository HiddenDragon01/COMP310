// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include "shell.h"
#include "shellmemory.h"
#include "kernel.h"
#include "memorymanager.h"

// Checks if arguments are valid. If so, it calls myinit on arguments and then calls scheduler
void exec(char *arr[]) {
	

	if (arr[1] == NULL) {
		printf("Unknown command\n");
		quit = 1;
		return;
	}

	if (arr[2] == NULL) {
		
		int error = myinit(arr[1]);

		if (error == 1) {
			printf("Script %s not found\n", arr[1]);
			quit = 1;
			return;
		}
		
		scheduler();
		return;
	}

	if (arr[3] == NULL) {

		
		for (int i = 1; i < 3; i++) {
			int error = myinit(arr[i]);
			if (error == 1) {
				printf("Script %s not found\n", arr[i]);
				quit = 1;
				return;
			}
		}

		scheduler();
		return;
	}

	if (arr[4] == NULL) {


		for (int i = 1; i < 4; i++) {
                        int error = myinit(arr[i]);
                        if (error == 1) {
				printf("Script %s not found\n", arr[i]);
				quit = 1;
                                return;
                        }
                }

                scheduler();
		return;
	}

	printf("Unknown command\n");

	return;
}



// Compares argument with different possibilities and takes corresponding action
void interpreter(char *arr[]) {
	
	if (strcmp(*arr, "help") == 0) {
		
		if (arr[1] != NULL) {
                        printf("Unknown command\n");
			quit = 1;
                        return;
                }
		
		printf("-------------------------------------------------------------------------------------------------------\n");
        	printf("COMMANDS\t\t\tDESCRIPTIONS\n");
        	printf("-------------------------------------------------------------------------------------------------------\n");
       	 	printf("help\t\t\t\tDisplays all commands\n");
        	printf("quit\t\t\t\tTerminates the shell\n");
        	printf("set VAR STRING\t\t\tAssigns the value STRING to the shell memory variable VAR\n");
        	printf("print VAR\t\t\tDisplays the STRING value assigned to the shell memory variable VAR\n");
        	printf("run SCRIPT.TXT\t\t\tExecutes the file SCRIPT.txt\n");
        	printf("exec p1 p2 p3\t\t\tExecutes programs p1 p2 p3 concurrently\n");
        	printf("-------------------------------------------------------------------------------------------------------\n");

		return;
	} 

	if (strcmp(*arr, "quit") == 0) {


		if (arr[1] != NULL) {
                	printf("Unknown command\n");
			quit = 1;
			return;
        	}


		printf("Bye!\n");

		exit(0);

		return;

	}


	if (strcmp(*arr, "set") == 0) {

		char *arg1 = arr[1];
		
		if (arg1 == NULL) {
			printf("Unknown command\n");
			quit = 1;
			return;
		}

		char *arg2 = arr[2];
                
                if (arg2 == NULL) {
                        printf("Unknown command\n");
			quit = 1;
			return;
                }

		if (arr[3] != NULL) {
                        printf("Unknown command\n");
			quit = 1;
                        return;
                }


		StoreMemory(arg1, arg2);
		return;
        }	

	if (strcmp(*arr, "print") == 0) {

                char *arg1 = arr[1];
                if (arg1 == NULL) {
                        printf("Unknown command\n");
			quit = 1;
                        return;
                }

		if (arr[2] != NULL) {
                        printf("Unknown command\n");
			quit = 1;
                        return;
                }

		printVariable(arg1);	
		return;	
	
	}

	if (strcmp(*arr, "run") == 0) {
		
		char *arg1 = arr[1];

                if (arg1 == NULL) {
                        printf("Unknown command\n");
			quit = 1;
                        return;
                }

		if (arr[2] != NULL) {
                        printf("Unknown command\n");
			quit = 1;
                        return;
                }
		
		FILE *x = fopen(arg1, "r");		
		if (x == NULL) {
			printf("Script not found\n");
			return;
		} 
		char command[1000];
		quit = 0;
		printf("/////////////////////////////// STARTING EXECUTION OF %s ///////////////////////////////\n",arg1);

		while (fgets (command, 1000, x)) {
			if (quit == 1) {
				break;
			}


			char *tok[1000], *str;
			str = malloc(256);
			memset( str, 0x00, 256);
			int ind = 0;
                	for (int i = 0; command[i] != '\0' && command[i] != '\n'; i++) {
                        	*(str + (ind++)) = command[i];
                	}
			parse(str,tok);
			if (tok[0] == NULL) {
				printf("Unknown command\n");
				break;
			}
			interpreter(tok);
			free(str);
			
		}

		printf("/////////////////////////////// Terminating execution of %s ///////////////////////////////\n",arg1);
		
		fclose (x);
		return;

	}

	if (strcmp(*arr, "exec") == 0) {
		printf("|----------| ");
    		printf("\tSTARTING CONCURRENT PROGRAMS ( ");	
		printf(")\t|----------|\n");
		exec(arr);
		printf("|----------| ");
    		printf("\tTERMINATING ALL CONCURRENT PROGRAMS");
    		printf("\t|----------|\n");
		return;	
        }


	printf("Unknown command\n");
	quit = 1;

}
