// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


// Define PCB and addToRAM function

struct PCB;
void addToRAM(char *fileName, struct PCB* new);
