// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020

// Define functions for shell

void parse(char *string, char *tokens[]);
int quit;
int shellUI();
