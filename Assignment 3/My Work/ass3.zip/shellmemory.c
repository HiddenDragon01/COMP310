// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


#include<stdio.h>
#include<string.h>
#include<stdlib.h>

// Memory struct

struct mem {
	char *var;
	char *value;

};

struct mem *memory;

// Which index at currently
int memindex;


// Allocate memory struct
void allocateMemory() {
	memory = malloc (1000 * sizeof(struct mem));
	memindex = 0;
}


// Store char *a = char *b in memory struct
void StoreMemory(char *a, char *b) {

	for (int i = 0; i < memindex; i++) {
                if (strcmp(memory[i].var, a) == 0) {
			memory[i].value = b;
                        return;
                }
        }
	memory[memindex].var = a;
	memory[memindex++].value = b;
}

// Prints the value of char *a 
void printVariable(char *a) {
	
	for (int i = 0; i < memindex; i++) {
		if (strcmp(memory[i].var, a) == 0) {
			printf("%s\n", memory[i].value);
			return;
		}
	}
	printf("Variable does not exist\n");
}

