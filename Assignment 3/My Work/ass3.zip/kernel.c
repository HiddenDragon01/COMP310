// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020



#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "pcb.h"
#include "cpu.h"
#include "shell.h"
#include "ram.h"

// Define ready list and other data structures
struct rQueue {
	
	struct PCB* curPCB;
	struct rQueue* next;
	struct rQueue* prev;

};

struct rQueue* head;
struct rQueue* tail;
char *ram[40];
struct CPU *cp;

// Add the PCB to the ready list
void addToReady(struct PCB* cur) {
	
	
	if ((head)->curPCB == NULL) {
		
		(head)->curPCB = cur;
		(tail)->curPCB = cur;
		return;
	}


        struct rQueue* new = (struct rQueue*)malloc(sizeof(struct rQueue));

        new->curPCB = cur;

        new->next = tail;

        new->prev = NULL;

	(tail)->prev = new;

	tail = new;

	if (head->prev == NULL) {
		head->prev = tail;
	}



}

// Make a PCB, add the PCB to the ready list, and then add to ram
int myinit(char *fileName) {

	
	struct PCB* newPCB = makePCB();
	addToReady(newPCB);
	addToRAM(fileName, newPCB);
	return 0;

}

// Copy the PCB's PC to the IP and run for a quanta
int scheduler() {

        cp->IP = (head)->curPCB->PC;

	run (cp->quanta);
		
	return 0;

}

// Initialize each cell of ram array to NULL, prepare Backing Store
int boot() {
	
	for (int i = 0; i < 40; i++) {

		ram[i] = NULL;

	}
	
	// Command to delete BackingStorage
	char command[50];
	// Command to make BackingStorage
	char command1[50];

   	strcpy(command, "rm -r -f BackingStorage");
	strcpy(command1, "mkdir BackingStorage");

	system(command);
	system(command1);


}



int kernel() {
	
	 // Data Structures:

        head = (struct rQueue*)malloc(sizeof(struct rQueue));
        tail = (struct rQueue*)malloc(sizeof(struct rQueue));
        cp = (struct CPU*)malloc(sizeof(struct CPU)); 
	
	cp->quanta = 2;

	shellUI();


	free(head);
	// Tail = Head at end
	free(cp);
	return 0;
}

int main() {
	
	int error=0;
	
	boot(); // First : actions performed by boot
 	error = kernel(); // Second: actions performed by kernel

 	return error;

}

