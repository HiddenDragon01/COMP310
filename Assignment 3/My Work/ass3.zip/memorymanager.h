// Name: Ryan Sowa
// ID: 260886668
// Date: March 11, 2020


// Defines functions for managing memory

int launcher(FILE *p, char* fileName, struct PCB* cur);
int countTotalPages(FILE *f);
void loadPage(int pageNumber, FILE *f, int frameNumber);
int findFrame();
int findVictim(struct PCB *p);
int updatePageTable(struct PCB *p, int pageNumber, int frameNumber, int victimFrame);

